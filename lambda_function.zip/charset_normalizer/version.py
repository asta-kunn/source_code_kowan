"""
Expose version
"""

__version__ = "3.4.0"
VERSION = __version__.split(".")
