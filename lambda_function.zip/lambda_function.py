import json
import requests

def lambda_handler(event, context):
    city = event.get('city')
    if not city:
        return {
            'statusCode': 400,
            'body': json.dumps('City is required')
        }

    # Contoh URL service yang dipanggil
    url = 'http://172.31.82.144/function/weather'
    payload = {"city": city}
    headers = {'Content-Type': 'application/json'}

    try:
        response = requests.post(url, json=payload, headers=headers)
        weather_data = response.json()
        temperature_celsius = weather_data.get('temperature')
        
        temp_value = float(temperature_celsius.replace("ºC", ""))
        temperature_fahrenheit = (temp_value * 9/5) + 32
        
        result = {
            "city": weather_data.get('city'),
            "temperature": f"{temperature_fahrenheit}ºF",
            "condition": weather_data.get('condition')
        }
        
        return {
            'statusCode': 200,
            'body': json.dumps(result)
        }

    except requests.exceptions.RequestException as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error while connecting to weather service: {str(e)}")
        }
